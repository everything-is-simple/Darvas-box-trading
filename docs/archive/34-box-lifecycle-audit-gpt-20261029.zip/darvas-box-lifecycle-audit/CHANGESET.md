# Proposed documentation changes (remote not yet published)

审计基于 GitHub `main` 分支 2026-10-29 代码/文档读取。由于当前 GitHub 连接器对 `create_branch`、`create_file` 写入均返回 HTTP 403 `Resource not accessible by integration`，以下是本地可应用的提案，不是已推送的提交。

`apply_lifecycle_audit.py` 会在用户自己的仓库 checkout 中同步这些改动：

| 文件 | 改动 |
|---|---|
| `docs/34-box-lifecycle-audit.md` | 新增完整审计、Box 状态图、Box→Signal→PlanOrder→Fill→Position 事件图、数学边界和验证顺序 |
| `docs/00-darvas-theory.md` | 重写 §3.7：更正“生命体”、离散状态模型、统计与线性变换表述 |
| `docs/01-requirements.md` | 加入 FR-206～FR-208 生命周期可追溯、交易接触链、重放一致性验收项（均标明待实现） |
| `docs/02-architecture.md` | 新增 Box 重建投影与交易对象的边界说明 |
| `docs/03-erd.md` | 校正 Box 状态迁移表，注明缺失的生命周期字段/迁移事件表；不改 SQL |
| `docs/04-api-contract.md` | 写明当前 Box 合约与 Signal→Order 链路的追踪边界 |
| `docs/05-task-breakdown.md` | 新增 M10.7 工程审计与验收步骤 |
| `docs/06-consistency.md` | 新增 Box 生命史不变量与迁移同步要求 |
| `docs/29-box-gradient-experiment-plan.md` | 将身份/窗口可追溯性设为现有 stop-ratchet 实验前置，不增第十一维 |
| `docs/README.md` 与根 `README.md` | 加入 34 文档入口，区分理论/实验纲领/专项审计 |

## 本提案不做的事情

- 不改 Go 策略实现。
- 不新增或修改任何 SQL migration、字段、索引或参数。
- 不改交易阈值，也不宣称统计实验已完成。
- 不把 Box 终态误称为持仓平仓，不把计划单误称为成交事实。
