# Darvas Box 生命周期审计文档补丁包

这个目录包含审计报告及一个安全的本地文档应用脚本。审计对象是 GitHub `main` 分支在 2026-10-29 可见的代码和文档。

## 内容

- `34-box-lifecycle-audit.md`：新增的生命周期与交易接触点审计文档。
- `apply_lifecycle_audit.py`：在本地仓库检查/应用相关文档同步，先检查所有锚点，再写文件；应用前会创建备份目录。

## 使用

在仓库根目录执行检查：

```bash
python /path/to/apply_lifecycle_audit.py . --check
```

检查通过后应用：

```bash
python /path/to/apply_lifecycle_audit.py . --apply
```

脚本不修改 Go 代码、SQL migration、参数或回测产物。它会更新 00–06、29、文档索引和根 README，使旧的 §3.7 生命体论述与实际代码相符，并明确将 schema/事件持久化列为待实现，不假装已存在。
