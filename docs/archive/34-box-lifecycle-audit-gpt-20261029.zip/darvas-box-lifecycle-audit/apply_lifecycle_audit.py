#!/usr/bin/env python3
"""Apply the 2026-10-29 Darvas Box lifecycle documentation audit locally.

The script only changes Markdown documentation. It never edits Go, SQL migrations,
parameters, historical backtest outputs, or the user's data. By default it runs a
non-writing check; pass --apply to write after all anchors have been validated.
"""
from __future__ import annotations
import argparse
from datetime import datetime
from pathlib import Path
import shutil
import sys

AUDIT_FILE = Path(__file__).with_name("34-box-lifecycle-audit.md")

THEORY_REPLACEMENT = '''### 3.7 Box 的数学结构与生命周期审计（2026-10-29）

> “生命体”是工程隐喻，不是实现证明。细化状态图见 [docs/34-box-lifecycle-audit.md](34-box-lifecycle-audit.md)。

**结论：Box 的算法内核已有状态与活动；完整生命周期的持久化证据尚不完备。** `Engine.Scan` 是确定性的离散时间转移函数；其 scanner/boxState 只在一次 Scan 调用内存活。每日持久化层一般以最近 800 根 K 线重建，再以数值上、下轨匹配记录。数据库保存的是重算状态投影，并非每次迁移的 append-only 事件账。因此不能笼统说 Box 已有完整出生、死亡和不可变谱系。

**当前可确认的事实：**
- BoxStatus 的真实枚举只有 forming、confirmed、broken_up、broken_down、invalid。上轨已确认但下轨仍形成的子阶段仍使用 forming，并由内部确认日/计数器区分。
- 上轨/下轨候选、计数器、确认日期、终态等构成状态向量；只看五个 status 标签不是完整状态。
- confirmed Box 突破或跌破时，旧 Box 当日进入 broken_up / broken_down，并从同一根 K 线开启新 forming Box；下轨确认前创新高、或宽度校验失败会 invalid 并重启。扫描结束时仍可保留 forming / confirmed 的未终结状态。
- top_confirmed / bottom_confirmed / broken_date 不是完整出生与死亡记录。没有独立 start_date、invalidated_date、terminal_reason 或每步迁移日志；created_at 是数据库插入时间，不等于市场中的出生日期。
- 重算窗口为最近 800 根交易日 K 线；BoxRepo 用上、下轨数值对匹配复用 ID，未被引用的旧行可能删除。故不能把当前 ID 与 prev_box_id 当作已承诺永久不变的生命谱系。

### 3.7.1 离散动力，而非微分方程

适当的抽象是 `X(t+1) = F(X(t), OHLCV(t+1), 参数)`，其中 X 包含候选价、计数、边界、确认日与链路上下文。规则使用交易日离散步进、守卫条件与阈值；核心实现不需要微积分或 ODE。对 top × 1.03、bottom × 0.97 的标量缩放可以做数值分析，但不是状态之间的线性变换。五态枚举也不足以形成完备的马尔可夫状态，因为下一迁移还取决于价位、计数器、参数和新 K 线。

### 3.7.2 确定性执行，统计验证

突破阈值、量比和一字板条件决定当前执行规则；统计学则检验这些确定性规则是否有跨样本稳定的收益/风险表现。不要在执行状态机里硬塞“概率买入”；应在回测/事件研究中检查样本量、胜率、每单位净利、Profit Factor、利润集中度、剔除前三赢家、MFE/MAE、回吐、止损上移滞后与跨年稳定性。单一年份或一只大赢家不构成 edge 证明。

### 3.7.3 Box 与订单不是同一个生命周期

breakout 只触发信号链候选；Signal、计划订单、成交 Fill 与 Position 是独立对象。只有买入 Fill 被账本应用后才创建 Position。平仓既有 Box 下轨 / failed-breakout 路径，也有 position.stop_price、time_stop_noprofit、人工及复权处理路径；Box broken_down 本身不代表已成交平仓。首次触发价 top × 1.03、初始存储止损 top × 0.97 对计划触发价对应约 5.83% 距离，需明确语义并做分布研究，不能把它口头简化为 3%。

**追踪实验顺序：** 先验证状态迁移边界、重复重算确定性与全量/增量/800 根窗口差异，再做 Box 生命周期事件视图，最后按 docs/29 已排队的 Box-driven stop-ratchet 进行事件研究。持久化迁移日志或 immutable Box identity 是后续 schema 设计提案，不是本轮已经实现的功能。详见 [docs/34-box-lifecycle-audit.md](34-box-lifecycle-audit.md) 与 [docs/29-box-gradient-experiment-plan.md](29-box-gradient-experiment-plan.md)。

---'''

ARCH_SECTION = '''## 10. Box 生命周期与交易事件边界（2026-10-29 审计）

本节为现状与目标边界说明，不声称已经增加数据库事件表或接口字段。

### 10.1 当前计算/持久化路径

OHLCV as-of 日期 → 纯函数 Engine.Scan（一次性状态向量）→ BoxRepo.UpsertBoxes（按上下轨值复用 ID 的重建投影）→ signal.Evaluate（只处理跟踪池观察对象）→ planner.Build（T+1 计划）→ 人工录入或 match 撮合 → ledger.ApplyFill（持仓与成交账本）。

Box Engine 的“活动”发生在 Scan 的每根 K 线步进；持久层不是 Box 内部状态的 checkpoint/event sourcing。常规每日路径读取最近 800 根交易日数据重建 Box；其他股票是否重算还受增量预过滤影响。因此不能把每天一次 boxscan 误解成全市场所有 Box 实例都有完整连续事件记录。

### 10.2 五个独立领域对象

- **Box**：价格结构状态投影，支持箱体阶梯关联。
- **Signal**：某一时点某一跟踪对象满足条件的事件，按同日幂等追加。
- **PlanOrder**：某个计划日拟于下一交易日执行的订单，不等于成交。
- **Fill**：人工回录或模拟撮合形成的成交事实，是账本应用依据。
- **Position**：由买入 Fill 创建、由卖出 Fill 更新或关闭的持仓事实。

当前 signal 带 box_id，但 plan_order 没有强类型 source_signal_id 外键；理由 JSON 留有部分规则上下文，不能等同端到端不可变事件关联。

### 10.3 建议的目标数据契约

先做确定性/窗口差异测试和离线事件视图。若结果证明持久追踪确有必要，再设计追加式 Box transition event、不可变逻辑 Box identity、起始/终止时间和 reason，以及从 Signal 到 PlanOrder 的显式来源关联。任何 schema 变化都必须追加新 migration，并同步更新 docs/03、docs/04、docs/06 与测试；本轮只是静态审计，不改变存量 schema。'''

API_SECTION = '''## 10. Box 生命周期合约边界（2026-10-29）

contract.Box 的现有字段为 ID、Code、Top、Bottom、TopConfirmed、BottomConfirmed、Status、PrevBoxID、BrokenDate。BoxStatus 仍是五值枚举；上轨已确认但下轨尚未确认的阶段使用 forming，由确认日期/内部计数状态区分，不存在独立的 forming_bottom 枚举值。

现有合约没有逻辑 start_date、invalidated_date、terminal_reason、状态迁移列表或数据窗口来源字段。ID 是数据库代理主键，但 BoxRepo 当前通过上下轨数值对复用数据库 ID；因此合约尚未承诺该 ID 是重算窗口变化后不可变的逻辑实例 ID。

交易链需要继续区分：
- Signal.BoxID 是信号触发时关联的 Box；
- 当前 PlanOrder 不包含强类型 source_signal_id；
- Fill 可以通过 plan_order_id 匹配订单，手工成交也可能没有对应计划订单；
- Position.EntryBoxID 记录入场 Box 关联，但不构成完整的 Box 迁移事件历史。

以上是现有事实。若要添加 event 或 identity 字段，须先更新 contract、schema migration、docs/03 ERD、docs/06 一致性规则与测试；本节不代表接口字段已经增加。'''

TASK_SECTION = '''## M10.7 · Box 生命周期完整性审计（2026-10-29）

**状态：文档审计完成；代码、schema 与回测实验尚未完成。** 本项是工程正确性与可观测性前置，不增加 docs/00 §3.6 的十维策略研究编号，也不更改生产交易规则。

| 子任务 | 内容 | 验收 |
|---|---|---|
| M10.7a 状态边界测试 | 上轨候选重置、下轨候选重置、宽度失败、突破、跌破、终态后新 Box | 每种合法/非法迁移均有测试；终态不可逆；新 Box 只建一次 |
| M10.7b 重放确定性 | 同输入同参数重复 Scan；同日 Upsert 幂等；prev_box_id 无环 | 逐字段一致；幂等；链路无环 |
| M10.7c 重建窗口对照 | 全量、增量、最近 800 根窗口逐日对比 Box / Signal / PlanOrder | 差异归因为窗口截断、预过滤或数据，不允许静默接受 |
| M10.7d 生命周期事件视图 | 离线重建首次观测、确认、终态、上移 stop 事件 | 左截断和未终结对象显式标识；不猜测缺失日期 |
| M10.7e 持久化设计（条件任务） | 若离线结果证实需要，再设计实例身份/事件表/source_signal_id | 新 migration + docs/03 + docs/04 + docs/06 + 测试同批变更 |

顺序约束：先完成 a–d，再决定 e 是否值得实现。Box-driven stop-ratchet 实验仍按 docs/29 的实验纲领执行，但报告必须说明输入窗口和身份可追溯性的限制。'''

CONSISTENCY_SECTION = '''## 8. Box 生命周期一致性补充（2026-10-29）

以下分为“当前可以校验的不变量”和“实现生命周期账本后才能校验的目标不变量”，不得混为已经落地的能力。

| 不变量 | 目标校验 | 当前状态 |
|---|---|---|
| 相同 K 线和参数 → 相同 Box 序列 | 对 Scan 输出逐字段比较 | 引擎设计为纯函数；仍需针对边界迁移与窗口做自动验收 |
| Box 状态迁移合法 | forming 子阶段、confirmed、broken_up/down、invalid 的守卫条件逐项校验 | 逻辑主要在 engine 内；schema 不存完整迁移日志 |
| 一个逻辑 Box 至多一个终态 | 终态不可逆、同一事件不能重复消费 | 现有 Box 表保存当前重建投影，不足以永久证明完整生命周期 |
| Box 链路无环且前驱时间早于后继 | prev_box_id 路径、创建/终态日期顺序检查 | 已有链路校验应继续；窗口重算/ID 复用仍需单独测 |
| Box → signal → plan/order → fill → position 可追溯 | 每个阶段保留源事件标识及时间/价格上下文 | signal 有 box_id；plan_order 无 source_signal_id 强引用，当前只能部分追踪 |
| 所有判定遵守 as-of，无未来信息 | 每个事件只用时点及之前的数据 | 继续沿用回放 as-of 审计；窗口对照是另一个维度 |
| Box 终态与 Position 关闭不混淆 | 交易报告按真实 Fill/exit reason 归因 | 当前本来就是不同对象；报表与事件研究必须保持区分 |

任何新增生命周期字段或事件表都必须遵循本文件 §2 的契约变更协议：只追加 migration，不改已发布 SQL；同步 docs/03、docs/04 与测试。本文登记的是目标不变量，不代表本轮已新增数据库支持。'''


def read(path: Path) -> str:
    if not path.is_file():
        raise FileNotFoundError(f"Missing target: {path}")
    return path.read_text(encoding="utf-8")

def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected anchor exactly once, found {count}")
    return text.replace(old, new, 1)

def replace_section(text: str, startswith: str, end_prefix: str, replacement: str, label: str) -> str:
    lines = text.splitlines()
    start = [i for i, line in enumerate(lines) if line.startswith(startswith)]
    if len(start) != 1:
        # Idempotent: if replacement section exists, leave it alone.
        if len(start) == 0 and startswith in text:
            return text
        if len(start) == 0 and replacement.splitlines()[0] in text:
            return text
        raise ValueError(f"{label}: start heading match count={len(start)}")
    s = start[0]
    ends = [i for i in range(s + 1, len(lines)) if lines[i].startswith(end_prefix)]
    if len(ends) != 1:
        raise ValueError(f"{label}: end heading match count={len(ends)}")
    e = ends[0]
    return "\n".join(lines[:s] + replacement.splitlines() + [""] + lines[e:]) + "\n"

def append_section_if_missing(text: str, heading: str, body: str) -> str:
    if heading in text:
        return text
    return text.rstrip() + "\n\n---\n\n" + body.strip() + "\n"

def build_changes(root: Path) -> dict[Path, str]:
    docdir = root / "docs"
    audit_doc = AUDIT_FILE.read_text(encoding="utf-8")
    changes: dict[Path, str] = {}

    p = docdir / "00-darvas-theory.md"
    t = read(p)
    t = replace_section(t, "### 3.7 箱体的数学与哲学结构", "## 4.", THEORY_REPLACEMENT, "00 §3.7")
    changes[p] = t

    p = docdir / "01-requirements.md"
    t = read(p)
    req = "- **FR-205** 对任意股票输出箱体全景JSON（供GUI画阶梯图）"
    extra = req + "\n- **FR-206（新增需求，待实现）** Box 生命周期可追溯：逻辑实例身份、起始日期、终态日期与终止原因必须有明确语义；窗口首项出生未知时须显式标注，不得伪造。\n- **FR-207（新增需求，待实现）** 交易接触链可审计：Box 迁移 → signal → plan/order → fill → position 的来源关系应可追踪；必须区分信号/计划/成交/持仓状态。\n- **FR-208（新增验收项，待实现）** 同输入同参数重放结果确定且幂等；需比较全量扫描、增量扫描与 800 根窗口重建，差异必须有可解释的窗口/数据原因。"
    if "FR-206（新增需求，待实现）" not in t:
        t = replace_once(t, req, extra, "01 FR-205")
    changes[p] = t

    p = docdir / "02-architecture.md"
    changes[p] = append_section_if_missing(read(p), "## 10. Box 生命周期与交易事件边界", ARCH_SECTION)

    p = docdir / "03-erd.md"
    t = read(p)
    if "**审计边界（当前 schema 事实）**" not in t:
        t = replace_section(t, "### 2.1 `box.status`", "### 2.2 `watch.stage`", "### 2.1 `box.status`\n\n| 迁移/阶段 | 触发 | 语义与守卫 |\n|------|------|------|\n| → forming | 扫描中启动新 Box | 真实逻辑出生日期目前没有单独字段 |\n| forming → forming | 上轨未确认阶段创新高 | 更新 top 候选并重置计数器 |\n| forming → forming | 上轨已确认、下轨尚未确认 | 内部子阶段变化；枚举仍是 forming |\n| forming → confirmed | 连续 N 日未再创新低且宽度校验通过 | top>bottom，width≥box.min_width |\n| confirmed → broken_up | 收盘>top×buy.premium、量≥此前均量×box.volmult、非一字板 | 终结旧 Box，并由同一根 K 线开启新 forming |\n| confirmed → broken_down | 收盘<bottom | 终结旧 Box，并由同一根 K 线开启新 forming；信号与成交仍是后续对象 |\n| forming → invalid | 下轨确认前创新高或宽度不达标 | 标记作废并从当前 K 线重启 |\n\n**审计边界（当前 schema 事实）：** box 表有 top_confirmed、bottom_confirmed、status、prev_box_id、broken_date 与 created_at，但没有逻辑 start_date、invalidated_date、terminal_reason 或 transition event 表。created_at 表示数据库行插入时间。Engine.Scan 的内部计数器不会被持久化为跨调用 checkpoint；常规每日扫描以最近 800 根 K 线重建，而 UpsertBoxes 用上下轨价格对复用 ID。因此当前 ERD 表达的是重算后的 Box 投影，不是完整事件溯源模型。此项为审计结论，本次不修改已发布 migration。\n\n", "03 box status")
    changes[p] = t

    p = docdir / "04-api-contract.md"
    changes[p] = append_section_if_missing(read(p), "## 10. Box 生命周期合约边界", API_SECTION)

    p = docdir / "05-task-breakdown.md"
    changes[p] = append_section_if_missing(read(p), "## M10.7 · Box 生命周期完整性审计", TASK_SECTION)

    p = docdir / "06-consistency.md"
    changes[p] = append_section_if_missing(read(p), "## 8. Box 生命周期一致性补充", CONSISTENCY_SECTION)

    p = docdir / "29-box-gradient-experiment-plan.md"
    t = read(p)
    queue_heading = "## 五之二、待做实验队列（2026-10-28 B-4 收官后重排）"
    queue_note = "> **2026-10-29 Box 生命周期审计前置条件**：见 docs/34。它是工程正确性/观测完整性，不是第十一维策略因子；不改变十维编号、策略参数或既定队列。止损随 Box 上移研究开始统计前，必须明确 800 根 K 线窗口、Box ID 复用与左截断边界；不能把重建投影误当作完整、不可变的生命史。"
    if "Box 生命周期审计前置条件" not in t:
        t = replace_once(t, queue_heading, queue_note + "\n\n" + queue_heading, "29 queue heading")
    stop_heading = "### 止损随 box 上移 · 事件研究（维度 8/9，A 类零成本，队列 2.1-1，2026-10-29 立项）"
    stop_note = "> **生命周期口径门槛（2026-10-29）**：A 类研究先核实事件日期与 Box 身份。现有引擎是确定性 Scan 重建，常规路径读最近 800 根 K 线，BoxRepo 以价格对复用 ID；报告须区分“窗口内重建得到的事件”与“已被持久化证明的完整生命周期”。若关键事件无法可靠关联，先做 A0/A1 工程核验，不得把缺失记录默认为没有发生。\n\n"
    if "生命周期口径门槛（2026-10-29）" not in t:
        t = replace_once(t, stop_heading, stop_note + stop_heading, "29 stop-ratchet heading")
    changes[p] = t

    p = docdir / "README.md"
    t = read(p)
    index_heading = "## archive/（历史档案，不作为事实源）"
    index_block = "### 第三层：工程专项审计（非 SSoT，1 文件）\n\n| 文档 | 职责 | 边界 |\n|---|---|---|\n| [34-box-lifecycle-audit.md](34-box-lifecycle-audit.md) | Box 状态/生命周期、Box→信号→计划→成交→持仓事件链，以及离散数学边界的工程审计 | 现状审计与待实现契约；不替代 00–06 的事实源，不增加 docs/29 十维之外的策略维度 |\n\n"
    if "34-box-lifecycle-audit.md" not in t:
        t = replace_once(t, index_heading, index_block + index_heading, "docs index")
    lines = t.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("**00-06 是宪法与工程基准"):
            lines[i] = "**00-06 是宪法与工程基准；29 是唯一十维实验纲领；34 是非 SSoT 的 Box 生命周期专项审计，不代表代码/schema 已实现目标能力；experiments/ 是实验报告事实源；archive/ 与 git 历史是旧稿。**"
            break
    changes[p] = "\n".join(lines) + "\n"

    p = root / "README.md"
    t = read(p)
    linkline = "| [docs/06-consistency.md](docs/06-consistency.md) | ERD/API一致性维护机制（三道防线） |"
    extra_links = linkline + "\n| [docs/29-box-gradient-experiment-plan.md](docs/29-box-gradient-experiment-plan.md) | Box 十维唯一实验纲领（策略参数实验与判据） |\n| [docs/34-box-lifecycle-audit.md](docs/34-box-lifecycle-audit.md) | Box 生命周期与交易接触点审计（现状、状态图、数学边界、待验证项） |"
    if "docs/34-box-lifecycle-audit.md" not in t:
        t = replace_once(t, linkline, extra_links, "root doc table")
    structline = "docs/                  # 00-06七份文档"
    if structline in t:
        t = replace_once(t, structline, "docs/                  # 00-06七份SSoT + 29实验纲领 + 34生命周期审计", "root structure")
    principle = "**单一理论原则**：本系统只实现达瓦斯箱体理论（见`docs/00-darvas-theory.md`），不引入MALF/立花/均线/MACD等任何其他理论的任何规则。"
    note = principle + "\n\n> 工程边界提示：Box 的突破/跌破只是交易事件链的一部分；计划订单不等于成交，成交才创建/更新持仓。移动 stop、time_stop_noprofit、人工或复权退出是不同出口。Box 生命周期审计见 [docs/34-box-lifecycle-audit.md](docs/34-box-lifecycle-audit.md)。"
    if "Box 生命周期审计见" not in t:
        t = replace_once(t, principle, note, "root principle")
    changes[p] = t

    # Include the new audit file in the set so that --check can validate path conflicts.
    audit_target = docdir / "34-box-lifecycle-audit.md"
    if audit_target.exists():
        # Already applied: content should match exactly; do not overwrite later edits.
        if audit_target.read_text(encoding="utf-8") != audit_doc:
            raise ValueError(f"{audit_target} exists with different content; inspect manually")
    else:
        changes[audit_target] = audit_doc
    return changes

def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("repo", nargs="?", default=".", help="local repository root")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true", help="validate anchors only; do not write")
    group.add_argument("--apply", action="store_true", help="apply Markdown-only changes")
    args = ap.parse_args()
    root = Path(args.repo).resolve()
    if not (root / "docs" / "00-darvas-theory.md").exists():
        print(f"Not a Darvas-box-trading checkout: {root}", file=sys.stderr)
        return 2
    try:
        changes = build_changes(root)
    except Exception as exc:
        print(f"CHECK FAILED: {exc}", file=sys.stderr)
        return 1
    print(f"Validated {len(changes)} path(s):")
    for path in changes:
        print(f"  {path.relative_to(root)}")
    if args.check:
        print("CHECK ONLY: no files written.")
        return 0
    backup_root = root / ".lifecycle-audit-backup" / datetime.now().strftime("%Y%m%d-%H%M%S")
    for path, text in changes.items():
        if path.exists():
            dest = backup_root / path.relative_to(root)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8", newline="\n")
    print(f"Applied Markdown changes. Backups of overwritten files: {backup_root}")
    print("No Go source, SQL migration, parameters, or backtest outputs were changed.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
